# NEXUS — Life OS

A private, local-first mobile web app for journalling, food tracking, calendar events, reminders and goals.

## Fastest way to use it on iPhone
1. Upload this folder to any static host (GitHub Pages, Netlify, Cloudflare Pages, etc.).
2. Open the HTTPS link in Safari.
3. Tap Share → Add to Home Screen.
4. Launch NEXUS from the icon. It runs fullscreen like an app.

All app data is stored in the browser on that device. Use Settings → Export backup regularly.

## Important limitation
This static version can track reminders and show when they are due inside the app, but iOS does not let a purely local static PWA schedule reliable background push notifications without a push/server component.
